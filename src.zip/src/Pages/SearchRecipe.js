import React, { useState } from "react";

function SearchRecipe() {
  const recipes = ["Biryani", "Puri", "Pongal", "Pizza", "Pasta", "Idli"];
  const [searchTerm, setSearchTerm] = useState("");

  const filteredRecipes = recipes.filter((recipe) =>
    recipe.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div style={{ textAlign: "center", marginTop: "50px" }}>
      <h1>Search Recipe</h1>
      <input
        type="text"
        placeholder="Search recipe..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        style={{ padding: "10px", width: "250px", marginRight: "10px" }}
      />
      <button style={{ padding: "10px 20px" }}>Search</button>

      <ul style={{ marginTop: "20px", listStyle: "none" }}>
        {filteredRecipes.length > 0 ? (
          filteredRecipes.map((recipe, index) => (
            <li key={index} style={{ fontSize: "18px", margin: "5px 0" }}>
              {recipe}
            </li>
          ))
        ) : (
          <p>No recipes found</p>
        )}
      </ul>
    </div>
  );
}

export default SearchRecipe;
