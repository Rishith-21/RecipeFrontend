import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Register.css"; // We'll style here

function Register() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({ username: "", email: "", password: "" });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("User Registered:", formData);
    navigate("/search");
  };

  return (
    <div className="register-container">
      <div className="image-section">
       <img
  src="/images/RRRR.jpg"
  alt="Pizza"
  height="50%"
  width="25%"
/>
        <div className="image-text">
          <h2>Need some Pizza, yo?</h2>
          <p>C'mon and order from nearby Pizza delivery and pickup restaurants</p>
        </div>
      </div>

      <div className="form-section">
        <form onSubmit={handleSubmit}>
          <h2>Sign Up</h2>
          <input
            type="text"
            name="username"
            placeholder="Username"
            value={formData.username}
            onChange={handleChange}
            required
          />
          <input
            type="email"
            name="email"
            placeholder="E-mail"
            value={formData.email}
            onChange={handleChange}
            required
          />
          <input
            type="password"
            name="password"
            placeholder="Password"
            value={formData.password}
            onChange={handleChange}
            required
          />
          <button type="submit">Sign Up</button>
        </form>
      </div>
    </div>
  );
}

export default Register;
