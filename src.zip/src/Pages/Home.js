import React from "react";
import { useNavigate } from "react-router-dom";
//import "./Home.css";

function Home() {
  const navigate = useNavigate();

 const recipes = [
  {
    name: "Biryani",
    image: "https://images.unsplash.com/photo-1601050690597-dfcbf5a0a6b6?auto=format&fit=crop&w=400&q=80"
  },
  {
    name: "Puri",
    image: "https://images.unsplash.com/photo-1631980875492-18dbf2e54f25?auto=format&fit=crop&w=400&q=80"
  },
  {
    name: "Pongal",
    image: "https://images.unsplash.com/photo-1600751551858-0f253d1f1d07?auto=format&fit=crop&w=400&q=80"
  }
];
// ...existing code...

  return (
    <div className="home-container">
      <h1>Welcome to Recipe World 🍽</h1>
      <p>Discover and search your favorite recipes</p>

      <div className="recipe-grid">
        {recipes.map((recipe, index) => (
          <div key={index} className="recipe-card">
            <img src={recipe.image} alt={recipe.name} />
            <h3>{recipe.name}</h3>
          </div>
        ))}
      </div>

      <button onClick={() => navigate("/search")} className="search-btn">
        Search Recipes
      </button>
    </div>
  );
}

export default Home;
