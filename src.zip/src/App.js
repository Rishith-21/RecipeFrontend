import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Register from "./Pages/Register";
import SearchRecipe from "./Pages/SearchRecipe";
import Home from "./Pages/Home";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/Home" element={<Home/>} />
        <Route path="/" element={<Register />} />
        <Route path="/search" element={<SearchRecipe />} />
      </Routes>
    </Router>
  );
}

export default App;
